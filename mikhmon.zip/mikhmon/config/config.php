<?php  if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("HTTP/1.0 403 Forbidden", true, 403); echo "403 Forbidden";die();}
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>ZmdoaQ==');
