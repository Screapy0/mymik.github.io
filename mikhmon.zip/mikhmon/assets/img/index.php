<?php

include_once("../core/route.php");
e403();